﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CrawlerDataProject.Data;
using CrawlerDataProject.Models;
using HtmlAgilityPack;

namespace CrawlerDataProject.Areas.Admin.Controllers
{
    public class ArticlesController : Controller
    {
        private MyDbContext db = new MyDbContext();

        // GET: Admin/Articles
        public ActionResult Index()
        {
            return View(db.Articles.ToList());
        }

        // GET: Admin/Articles/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Article article = db.Articles.Find(id);
            if (article == null)
            {
                return HttpNotFound();
            }
            return View(article);
        }

        // GET: Admin/Articles/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admin/Articles/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Title,Content,Thumbnail,Author,SourceId")] Article article)
        {
            if (ModelState.IsValid)
            {
                db.Articles.Add(article);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(article);
        }

        // GET: Admin/Articles/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Article article = db.Articles.Find(id);
            if (article == null)
            {
                return HttpNotFound();
            }
            return View(article);
        }

        // POST: Admin/Articles/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Title,Content,Thumbnail,Author,SourceId")] Article article)
        {
            if (ModelState.IsValid)
            {
                db.Entry(article).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(article);
        }

        // GET: Admin/Articles/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Article article = db.Articles.Find(id);
            if (article == null)
            {
                return HttpNotFound();
            }
            return View(article);
        }

        // POST: Admin/Articles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Article article = db.Articles.Find(id);
            db.Articles.Remove(article);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
       
        public Article GetArticle(Article art)
        {
            var web = new HtmlWeb();
            HtmlDocument doc = web.Load(art.Url);
            var titleNode = doc.QuerySelector(art.Title);
            var title = titleNode.InnerText;
            var descriptionNode = doc.QuerySelector(art.Description);
            var desc = descriptionNode.InnerText;
            var contentNode = doc.QuerySelector(art.Content);
            var content = contentNode.InnerText;
            var thumbnailNode = doc.QuerySelector(art.Thumbnail);
            var thumbnail = thumbnailNode.Attributes["data-src"].Value;
            var authorNode = doc.QuerySelector(art.Author);
            var author = "";
            if (authorNode.InnerText.Length > 0)
            {
                author = authorNode.InnerText;
            }
            Article article = new Article()
            {
                Url = art.Url,
                Title = title,
                Content = content,
                Thumbnail = thumbnail,
                Author = author
            };
            return article;
        }
       
        //var hello = new HelloJob();
        //var article = hello.GetContent(url);
        //StdSchedulerFactory factory = new StdSchedulerFactory();
        //IScheduler sched = await factory.GetScheduler();
        //sched.Start();
        //IJobDetail job = JobBuilder.Create<HelloJob>()
        //    .WithIdentity("myjob", "group1")
        //    .Build();
        //ITrigger trigger = TriggerBuilder.Create()
        //    .WithIdentity("mytrigger", "group1")
        //    .StartNow()
        //    .WithSimpleSchedule(x => x
        //        .WithIntervalInSeconds(2)
        //        .RepeatForever())
        //    .Build();
        //sched.ScheduleJob(job, trigger);

        //    sourceBody.GetType = 1;

        //    switch (type)
        //    {
        //        case 1:
        //            break;
        //        case 2:
        //            var articles = listArticle();
        //            forea
        //            break;
        //    }
        //}

        //public Array<Article> listArticle()
        //{

        //}

        //public Article article(Source source)
        //{

        //}
    }
}
