﻿using CrawlerDataProject.Data;
using CrawlerDataProject.Models;
using CrawlerDataProject.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CrawlerURL;
using CrawlerContent;

namespace CrawlerDataProject.Areas.Admin.Controllers
{
  
    public class SourceController : Controller
    {
        HelloJob helloJob = new HelloJob();
        ContentJob contentJob = new ContentJob();

        MyDbContext db = new MyDbContext();
        public ActionResult Index()
        {
            return View(db.Sources.ToList());
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(SourceViewModel sourceViewModel)
        {
            var source = new Models.Source()
            {
                Name = sourceViewModel.Name
            };
            db.Sources.Add(source);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Details(int id, string source)
        {
            return View(helloJob.GetLinks(source));
        }
        public ActionResult GetArticle(string url)
        {
            contentJob.GetContent(url);
            return View();
        }
        [HttpGet]
        public ActionResult Edit(int id)
        { 
            var source = db.Sources.Find(id);
            return View(source);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Models.Source updateSource)
        {
            db.Entry(updateSource).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}