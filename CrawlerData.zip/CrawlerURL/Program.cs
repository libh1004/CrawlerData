﻿
using HtmlAgilityPack;
using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrawlerURL
{
    public class Program
    {
        private static async Task Main(string[] args)
        {
            //var getSources = await GetLinks(source);
            //getSource.ToString();
            //StdSchedulerFactory scheFactory = new StdSchedulerFactory();
            //IScheduler sche = await scheFactory.GetScheduler();
            //await sche.Start();
            //IJobDetail job = JobBuilder.Create<HelloJob>()
            //    .WithIdentity("myjob1", "group1")
            //    .Build();
            //ITrigger trigger = TriggerBuilder.Create()
            //    .WithIdentity("mytrigger1", "group1")
            //    .WithSchedule(CronScheduleBuilder.DailyAtHourAndMinute(20, 41))
            //    .ForJob(job)
            //    .Build();
            //sche.ScheduleJob(job, trigger);
         
        }
    
    }
}
