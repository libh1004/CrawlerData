﻿using HtmlAgilityPack;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrawlerURL
{
    public class HelloJob : IJob
    {
        //MyDbContext db = new MyDbContext();
        public async Task Execute(IJobExecutionContext context)
        {
            //    List<Article> articles = new List<Article>();
            //    var filterData = db.Sources;
            //    filterData = filterData.Where(x => x.Status = 3);
            //    foreach (var item in filterData)
            //    {
            //        articles.Add(GetContent(item.Url));
            //        item.Status = 4;// set flag to mark it done
            //    }

            //    // save articles to DB
            //    articles
        }

        public HashSet<string> GetLinks(string source)
        {
            Console.OutputEncoding = Encoding.UTF8;
            var web = new HtmlWeb();
            HtmlDocument doc = web.Load(source);
            var nodeList = doc.QuerySelectorAll(source);
            HashSet<string> setLink = new HashSet<string>();
            foreach (var node in nodeList)
            {
                var link = node.Attributes["href"].Value;
                if (string.IsNullOrEmpty(link))
                {
                    continue;
                }
                setLink.Add(link);
                Console.WriteLine(link.ToString());
            }
            return setLink;
            Console.ReadLine();
        }
       
    }
}
